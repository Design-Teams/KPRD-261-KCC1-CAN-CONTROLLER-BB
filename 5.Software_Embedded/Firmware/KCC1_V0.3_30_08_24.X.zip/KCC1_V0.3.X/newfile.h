/* 
 * File:   newfile.h
 * Author: rahul.chavan
 *
 * Created on June 26, 2024, 11:51 AM
 */

#ifndef NEWFILE_H
#define	NEWFILE_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* NEWFILE_H */

